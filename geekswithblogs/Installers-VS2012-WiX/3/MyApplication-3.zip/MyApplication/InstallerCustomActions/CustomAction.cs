﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Deployment.WindowsInstaller;

namespace InstallerCustomActions
{
    public class CustomActions
    {
        [CustomAction]
        public static ActionResult AssignEnvironmentSettings(Session session)
        {
            session.Log("Begin AssignEnvironmentSettings");
            session.Log(String.Format("Assigning configuration settings for {0}", session["APPENV"]));

            // Extract the configuration settings from the ConfigSettings table
            using (View v = session.Database.OpenView(String.Format(
                "SELECT Token, Data FROM ConfigSettings WHERE Environment = '{0}'",
                session["APPENV"]
                )))
            {
                v.Execute();
                
                using (Record r = v.Fetch())
                {
                    // Assign the key/value pair to a session-level MSI property
                    string token = r.GetString(1);
                    string data = r.GetString(2);
                    session.Log(String.Format("Assigning: {0} = {1}", token, data));
                    session[token] = data;
                    r.Close();
                }

                v.Close();
            }

            return ActionResult.Success;
        }
    }
}
